# MiniMagazin - proiect Svelte + FastAPI

Aplicatie web simpla pentru facultate: magazin online cu client, admin, backend FastAPI si baza de date SQLite.

## Pornire rapida

1. Instaleaza:
   - Python 3.11+
   - Node.js 20+ de pe https://nodejs.org

2. Ruleaza dublu click pe:
   - `start_backend.bat`
   - `start_frontend.bat`

3. Deschide in browser:
   - Frontend: http://localhost:5173
   - API docs: http://localhost:8000/docs

## Conturi demo

- Admin: `admin@magazin.ro` / `admin123`
- Client: `client@magazin.ro` / `client123`

## Ce contine proiectul

- `backend/app.py` - API FastAPI, autentificare, produse, comenzi, admin.
- `backend/magazin.db` - baza SQLite se creeaza automat la prima pornire.
- `frontend/src/App.svelte` - interfata pentru client si admin.
- `start_backend.bat` - creeaza mediul Python si porneste API-ul.
- `start_frontend.bat` - instaleaza dependentele Svelte si porneste site-ul.

## Functionalitati

- listare produse
- cautare produse
- adaugare in cos
- plasare comanda
- autentificare client/admin
- panou admin pentru produse
- panou admin pentru comenzi
- baza de date SQLite persistenta
