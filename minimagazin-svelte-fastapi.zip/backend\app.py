from datetime import datetime
from pathlib import Path
import secrets
import sqlite3
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


DB_PATH = Path(__file__).with_name("magazin.db")
sessions: dict[str, dict] = {}

app = FastAPI(title="MiniMagazin API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def row_to_dict(row):
    return dict(row) if row else None


def init_db():
    conn = db()
    cur = conn.cursor()
    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin', 'customer'))
        );

        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            price REAL NOT NULL,
            stock INTEGER NOT NULL,
            category TEXT NOT NULL,
            image_url TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            customer_name TEXT NOT NULL,
            customer_email TEXT NOT NULL,
            address TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'noua',
            total REAL NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            FOREIGN KEY(order_id) REFERENCES orders(id),
            FOREIGN KEY(product_id) REFERENCES products(id)
        );
        """
    )

    cur.execute("SELECT COUNT(*) AS total FROM users")
    if cur.fetchone()["total"] == 0:
        cur.executemany(
            "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
            [
                ("Administrator", "admin@magazin.ro", "admin123", "admin"),
                ("Client Demo", "client@magazin.ro", "client123", "customer"),
            ],
        )

    cur.execute("SELECT COUNT(*) AS total FROM products")
    if cur.fetchone()["total"] == 0:
        cur.executemany(
            """
            INSERT INTO products (name, description, price, stock, category, image_url)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    "Casti wireless",
                    "Casti Bluetooth confortabile, potrivite pentru cursuri online si muzica.",
                    149.99,
                    15,
                    "Electronice",
                    "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",
                ),
                (
                    "Rucsac laptop",
                    "Rucsac compact cu spatiu pentru laptop, caiete si accesorii.",
                    119.5,
                    20,
                    "Accesorii",
                    "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80",
                ),
                (
                    "Sticla termos",
                    "Termos metalic de 500 ml, pastreaza bauturile calde sau reci.",
                    59.99,
                    30,
                    "Lifestyle",
                    "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=80",
                ),
                (
                    "Agenda premium",
                    "Agenda datata pentru organizarea proiectelor si examenelor.",
                    34.9,
                    40,
                    "Papetarie",
                    "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=900&q=80",
                ),
            ],
        )

    conn.commit()
    conn.close()


@app.on_event("startup")
def startup_event():
    init_db()


class LoginIn(BaseModel):
    email: str
    password: str


class ProductIn(BaseModel):
    name: str = Field(min_length=2)
    description: str = Field(min_length=5)
    price: float = Field(gt=0)
    stock: int = Field(ge=0)
    category: str = Field(min_length=2)
    image_url: str = Field(min_length=5)


class OrderItemIn(BaseModel):
    product_id: int
    quantity: int = Field(gt=0)


class OrderIn(BaseModel):
    customer_name: str = Field(min_length=2)
    customer_email: str = Field(min_length=5)
    address: str = Field(min_length=5)
    items: list[OrderItemIn]


class StatusIn(BaseModel):
    status: str


def current_user(authorization: Annotated[str | None, Header()] = None):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Autentificare necesara")
    token = authorization.replace("Bearer ", "", 1)
    user = sessions.get(token)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sesiune invalida")
    return user


def admin_user(user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Doar adminul are acces")
    return user


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/auth/login")
def login(payload: LoginIn):
    conn = db()
    cur = conn.execute(
        "SELECT id, name, email, role FROM users WHERE email = ? AND password = ?",
        (payload.email, payload.password),
    )
    user = row_to_dict(cur.fetchone())
    conn.close()
    if not user:
        raise HTTPException(status_code=400, detail="Email sau parola gresita")

    token = secrets.token_hex(24)
    sessions[token] = user
    return {"token": token, "user": user}


@app.get("/products")
def list_products(search: str = ""):
    conn = db()
    query = "SELECT * FROM products"
    params: tuple = ()
    if search:
        query += " WHERE lower(name) LIKE ? OR lower(category) LIKE ?"
        like = f"%{search.lower()}%"
        params = (like, like)
    query += " ORDER BY id DESC"
    products = [row_to_dict(row) for row in conn.execute(query, params)]
    conn.close()
    return products


@app.post("/products", dependencies=[Depends(admin_user)])
def create_product(payload: ProductIn):
    conn = db()
    cur = conn.execute(
        """
        INSERT INTO products (name, description, price, stock, category, image_url)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (payload.name, payload.description, payload.price, payload.stock, payload.category, payload.image_url),
    )
    conn.commit()
    product = row_to_dict(conn.execute("SELECT * FROM products WHERE id = ?", (cur.lastrowid,)).fetchone())
    conn.close()
    return product


@app.put("/products/{product_id}", dependencies=[Depends(admin_user)])
def update_product(product_id: int, payload: ProductIn):
    conn = db()
    conn.execute(
        """
        UPDATE products
        SET name = ?, description = ?, price = ?, stock = ?, category = ?, image_url = ?
        WHERE id = ?
        """,
        (payload.name, payload.description, payload.price, payload.stock, payload.category, payload.image_url, product_id),
    )
    conn.commit()
    product = row_to_dict(conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone())
    conn.close()
    if not product:
        raise HTTPException(status_code=404, detail="Produs inexistent")
    return product


@app.delete("/products/{product_id}", dependencies=[Depends(admin_user)])
def delete_product(product_id: int):
    conn = db()
    cur = conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Produs inexistent")
    return {"deleted": True}


@app.post("/orders")
def create_order(payload: OrderIn, user=Depends(current_user)):
    if not payload.items:
        raise HTTPException(status_code=400, detail="Cosul este gol")

    conn = db()
    total = 0.0
    checked_items = []

    for item in payload.items:
        product = conn.execute("SELECT * FROM products WHERE id = ?", (item.product_id,)).fetchone()
        if not product:
            conn.close()
            raise HTTPException(status_code=404, detail=f"Produsul {item.product_id} nu exista")
        if product["stock"] < item.quantity:
            conn.close()
            raise HTTPException(status_code=400, detail=f"Stoc insuficient pentru {product['name']}")
        total += product["price"] * item.quantity
        checked_items.append((product, item.quantity))

    cur = conn.execute(
        """
        INSERT INTO orders (user_id, customer_name, customer_email, address, status, total, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user["id"],
            payload.customer_name,
            payload.customer_email,
            payload.address,
            "noua",
            round(total, 2),
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    order_id = cur.lastrowid

    for product, quantity in checked_items:
        conn.execute(
            "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)",
            (order_id, product["id"], quantity, product["price"]),
        )
        conn.execute("UPDATE products SET stock = stock - ? WHERE id = ?", (quantity, product["id"]))

    conn.commit()
    conn.close()
    return {"id": order_id, "total": round(total, 2), "status": "noua"}


@app.get("/orders")
def list_orders(user=Depends(current_user)):
    conn = db()
    if user["role"] == "admin":
        rows = conn.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    else:
        rows = conn.execute("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", (user["id"],)).fetchall()

    orders = []
    for row in rows:
        order = row_to_dict(row)
        items = conn.execute(
            """
            SELECT oi.quantity, oi.price, p.name
            FROM order_items oi
            JOIN products p ON p.id = oi.product_id
            WHERE oi.order_id = ?
            """,
            (order["id"],),
        ).fetchall()
        order["items"] = [row_to_dict(item) for item in items]
        orders.append(order)
    conn.close()
    return orders


@app.patch("/orders/{order_id}", dependencies=[Depends(admin_user)])
def update_order_status(order_id: int, payload: StatusIn):
    allowed = {"noua", "procesata", "livrata", "anulata"}
    if payload.status not in allowed:
        raise HTTPException(status_code=400, detail="Status invalid")
    conn = db()
    cur = conn.execute("UPDATE orders SET status = ? WHERE id = ?", (payload.status, order_id))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Comanda inexistenta")
    return {"updated": True}
