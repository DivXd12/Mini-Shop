<script>
  const API = 'http://127.0.0.1:8000';

  let user = JSON.parse(localStorage.getItem('user') || 'null');
  let token = localStorage.getItem('token') || '';
  let products = [];
  let orders = [];
  let cart = JSON.parse(localStorage.getItem('cart') || '[]');
  let search = '';
  let message = '';
  let error = '';
  let loading = false;
  let activeTab = user?.role === 'admin' ? 'admin' : 'shop';

  let loginForm = { email: 'client@magazin.ro', password: 'client123' };
  let checkout = { customer_name: user?.name || '', customer_email: user?.email || '', address: '' };
  let productForm = emptyProduct();
  let editingId = null;

  function emptyProduct() {
    return {
      name: '',
      description: '',
      price: 0,
      stock: 0,
      category: '',
      image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80'
    };
  }

  function saveSession(data) {
    token = data.token;
    user = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    checkout.customer_name = user.name;
    checkout.customer_email = user.email;
    activeTab = user.role === 'admin' ? 'admin' : 'shop';
  }

  function authHeaders() {
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  async function api(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders(),
        ...(options.headers || {})
      }
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.detail || 'A aparut o eroare');
    }
    return response.json();
  }

  async function loadProducts() {
    loading = true;
    try {
      products = await api(`/products?search=${encodeURIComponent(search)}`);
    } catch (err) {
      error = err.message;
    } finally {
      loading = false;
    }
  }

  async function loadOrders() {
    if (!token) return;
    try {
      orders = await api('/orders');
    } catch (err) {
      error = err.message;
    }
  }

  async function login() {
    clearAlerts();
    try {
      const data = await api('/auth/login', {
        method: 'POST',
        body: JSON.stringify(loginForm)
      });
      saveSession(data);
      message = `Bine ai venit, ${data.user.name}!`;
      await loadOrders();
    } catch (err) {
      error = err.message;
    }
  }

  function logout() {
    user = null;
    token = '';
    orders = [];
    activeTab = 'shop';
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }

  function addToCart(product) {
    clearAlerts();
    const found = cart.find((item) => item.id === product.id);
    if (found) {
      if (found.quantity < product.stock) found.quantity += 1;
    } else {
      cart = [...cart, { ...product, quantity: 1 }];
    }
    persistCart();
    message = `${product.name} a fost adaugat in cos.`;
  }

  function updateQuantity(id, quantity) {
    cart = cart
      .map((item) => (item.id === id ? { ...item, quantity: Math.max(1, Number(quantity)) } : item))
      .filter((item) => item.quantity > 0);
    persistCart();
  }

  function removeFromCart(id) {
    cart = cart.filter((item) => item.id !== id);
    persistCart();
  }

  function persistCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
  }

  $: cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  async function placeOrder() {
    clearAlerts();
    if (!user) {
      error = 'Trebuie sa fii autentificat ca sa plasezi comanda.';
      activeTab = 'login';
      return;
    }
    try {
      const data = await api('/orders', {
        method: 'POST',
        body: JSON.stringify({
          ...checkout,
          items: cart.map((item) => ({ product_id: item.id, quantity: item.quantity }))
        })
      });
      cart = [];
      persistCart();
      message = `Comanda #${data.id} a fost plasata. Total: ${data.total.toFixed(2)} lei.`;
      await loadProducts();
      await loadOrders();
      activeTab = 'orders';
    } catch (err) {
      error = err.message;
    }
  }

  function editProduct(product) {
    editingId = product.id;
    productForm = { ...product };
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function saveProduct() {
    clearAlerts();
    try {
      const method = editingId ? 'PUT' : 'POST';
      const path = editingId ? `/products/${editingId}` : '/products';
      await api(path, { method, body: JSON.stringify(productForm) });
      message = editingId ? 'Produs actualizat.' : 'Produs adaugat.';
      productForm = emptyProduct();
      editingId = null;
      await loadProducts();
    } catch (err) {
      error = err.message;
    }
  }

  async function deleteProduct(id) {
    clearAlerts();
    if (!confirm('Stergi produsul?')) return;
    try {
      await api(`/products/${id}`, { method: 'DELETE' });
      message = 'Produs sters.';
      await loadProducts();
    } catch (err) {
      error = err.message;
    }
  }

  async function updateStatus(orderId, status) {
    clearAlerts();
    try {
      await api(`/orders/${orderId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      await loadOrders();
      message = 'Status actualizat.';
    } catch (err) {
      error = err.message;
    }
  }

  function clearAlerts() {
    message = '';
    error = '';
  }

  loadProducts();
  loadOrders();
</script>

<header class="topbar">
  <div>
    <p class="eyebrow">Proiect facultate</p>
    <h1>MiniMagazin</h1>
  </div>
  <nav>
    <button class:active={activeTab === 'shop'} on:click={() => (activeTab = 'shop')}>Magazin</button>
    <button class:active={activeTab === 'cart'} on:click={() => (activeTab = 'cart')}>Cos ({cart.length})</button>
    {#if user}
      <button class:active={activeTab === 'orders'} on:click={() => (activeTab = 'orders')}>Comenzi</button>
      {#if user.role === 'admin'}
        <button class:active={activeTab === 'admin'} on:click={() => (activeTab = 'admin')}>Admin</button>
      {/if}
      <button on:click={logout}>Logout</button>
    {:else}
      <button class:active={activeTab === 'login'} on:click={() => (activeTab = 'login')}>Login</button>
    {/if}
  </nav>
</header>

<main>
  {#if message}<div class="alert success">{message}</div>{/if}
  {#if error}<div class="alert error">{error}</div>{/if}

  {#if activeTab === 'shop'}
    <section class="hero">
      <div>
        <p class="eyebrow">Produse simple, flux complet</p>
        <h2>Magazin online functional cu Svelte, FastAPI si SQLite</h2>
        <p>Adauga produse in cos, autentifica-te si plaseaza comenzi. Adminul poate modifica produsele si statusul comenzilor.</p>
      </div>
    </section>

    <section class="toolbar">
      <input bind:value={search} placeholder="Cauta produs sau categorie" on:input={loadProducts} />
      <span>{products.length} produse</span>
    </section>

    {#if loading}
      <p>Se incarca produsele...</p>
    {:else}
      <section class="grid">
        {#each products as product}
          <article class="product">
            <img src={product.image_url} alt={product.name} />
            <div class="product-body">
              <span class="tag">{product.category}</span>
              <h3>{product.name}</h3>
              <p>{product.description}</p>
              <div class="product-footer">
                <strong>{product.price.toFixed(2)} lei</strong>
                <span>Stoc: {product.stock}</span>
              </div>
              <button disabled={product.stock === 0} on:click={() => addToCart(product)}>
                {product.stock === 0 ? 'Stoc epuizat' : 'Adauga in cos'}
              </button>
            </div>
          </article>
        {/each}
      </section>
    {/if}
  {/if}

  {#if activeTab === 'login'}
    <section class="panel narrow">
      <h2>Autentificare</h2>
      <label>Email <input bind:value={loginForm.email} /></label>
      <label>Parola <input type="password" bind:value={loginForm.password} /></label>
      <button on:click={login}>Intra in cont</button>
      <p class="hint">Admin: admin@magazin.ro / admin123<br />Client: client@magazin.ro / client123</p>
    </section>
  {/if}

  {#if activeTab === 'cart'}
    <section class="panel">
      <h2>Cosul tau</h2>
      {#if cart.length === 0}
        <p>Cosul este gol.</p>
      {:else}
        <div class="cart-list">
          {#each cart as item}
            <div class="cart-row">
              <img src={item.image_url} alt={item.name} />
              <div>
                <strong>{item.name}</strong>
                <p>{item.price.toFixed(2)} lei / bucata</p>
              </div>
              <input type="number" min="1" max={item.stock} value={item.quantity} on:input={(event) => updateQuantity(item.id, event.target.value)} />
              <button class="secondary" on:click={() => removeFromCart(item.id)}>Sterge</button>
            </div>
          {/each}
        </div>
        <h3>Total: {cartTotal.toFixed(2)} lei</h3>
        <div class="form-grid">
          <label>Nume <input bind:value={checkout.customer_name} /></label>
          <label>Email <input bind:value={checkout.customer_email} /></label>
          <label class="wide">Adresa <textarea bind:value={checkout.address}></textarea></label>
        </div>
        <button on:click={placeOrder}>Plaseaza comanda</button>
      {/if}
    </section>
  {/if}

  {#if activeTab === 'orders'}
    <section class="panel">
      <h2>{user?.role === 'admin' ? 'Toate comenzile' : 'Comenzile mele'}</h2>
      <button class="secondary" on:click={loadOrders}>Reincarca</button>
      <div class="orders">
        {#each orders as order}
          <article class="order">
            <div>
              <h3>Comanda #{order.id}</h3>
              <p>{order.customer_name} - {order.customer_email}</p>
              <p>{order.address}</p>
              <p>{new Date(order.created_at).toLocaleString('ro-RO')}</p>
            </div>
            <div>
              <strong>{order.total.toFixed(2)} lei</strong>
              <p>Status: {order.status}</p>
              {#if user?.role === 'admin'}
                <select value={order.status} on:change={(event) => updateStatus(order.id, event.target.value)}>
                  <option value="noua">noua</option>
                  <option value="procesata">procesata</option>
                  <option value="livrata">livrata</option>
                  <option value="anulata">anulata</option>
                </select>
              {/if}
            </div>
            <ul>
              {#each order.items as item}
                <li>{item.quantity} x {item.name} ({item.price.toFixed(2)} lei)</li>
              {/each}
            </ul>
          </article>
        {/each}
      </div>
    </section>
  {/if}

  {#if activeTab === 'admin' && user?.role === 'admin'}
    <section class="admin-layout">
      <div class="panel">
        <h2>{editingId ? 'Editeaza produs' : 'Adauga produs'}</h2>
        <div class="form-grid">
          <label>Nume <input bind:value={productForm.name} /></label>
          <label>Categorie <input bind:value={productForm.category} /></label>
          <label>Pret <input type="number" step="0.01" bind:value={productForm.price} /></label>
          <label>Stoc <input type="number" bind:value={productForm.stock} /></label>
          <label class="wide">Imagine URL <input bind:value={productForm.image_url} /></label>
          <label class="wide">Descriere <textarea bind:value={productForm.description}></textarea></label>
        </div>
        <button on:click={saveProduct}>{editingId ? 'Salveaza modificarile' : 'Adauga produs'}</button>
        {#if editingId}
          <button class="secondary" on:click={() => { editingId = null; productForm = emptyProduct(); }}>Renunta</button>
        {/if}
      </div>

      <div class="panel">
        <h2>Produse existente</h2>
        <div class="admin-products">
          {#each products as product}
            <div>
              <img src={product.image_url} alt={product.name} />
              <strong>{product.name}</strong>
              <span>{product.price.toFixed(2)} lei, stoc {product.stock}</span>
              <button class="secondary" on:click={() => editProduct(product)}>Editeaza</button>
              <button class="danger" on:click={() => deleteProduct(product.id)}>Sterge</button>
            </div>
          {/each}
        </div>
      </div>
    </section>
  {/if}
</main>
